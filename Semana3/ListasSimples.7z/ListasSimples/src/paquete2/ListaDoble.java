package paquete2;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SALA I
 */
public class ListaDoble {
    public static void main(String[] args) {
        Operaciones listaDoble =new Operaciones();
        
        listaDoble.insertar(1);
        listaDoble.insertar(8);
        listaDoble.insertar(5);
        listaDoble.insertar(10);

        listaDoble.imprimir();
    }
}
