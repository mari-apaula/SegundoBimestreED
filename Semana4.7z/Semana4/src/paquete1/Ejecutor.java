/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package paquete1;



/**
 *
 * @author SALA I
 */
public class Ejecutor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        ArbolBinarioBusqueda bt = new ArbolBinarioBusqueda();
        
        bt.add(8);
        bt.add(6);
        bt.add(7);
        bt.add(5);


        
    }
    
}
