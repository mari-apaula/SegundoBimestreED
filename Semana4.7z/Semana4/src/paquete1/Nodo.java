/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete1;

/**
 *
 * @author SALA I
 */
public class Nodo {
    int dato;
    Nodo izquierda;
    Nodo derecho;
    Nodo raiz;

    public Nodo(int dato) {
        this.dato = dato;
        izquierda = null;
        derecho = null;
    }
    
    
}
